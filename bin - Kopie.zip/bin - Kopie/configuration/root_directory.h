const char * logl_root = "D:/UNI/Tool-_und_Pluginprogrammierung/Abgabe/Abgabe/TPOpenGLnew";
